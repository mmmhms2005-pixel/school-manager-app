package com.yourname.panchangam // Change this to match your actual project package name

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.util.*
import kotlin.math.*

class MainActivity : AppCompatActivity() {

override fun onCreate(savedInstanceState: Bundle?) {
super.onCreate(savedInstanceState)
setContentView(R.layout.activity_main)

// Linking UI elements from activity_main.xml
val etDay = findViewById<EditText>(R.id.etDay)
val etMonth = findViewById<EditText>(R.id.etMonth)
val etYear = findViewById<EditText>(R.id.etYear)
val btnCalculate = findViewById<Button>(R.id.btnCalculate)
val tvResult = findViewById<TextView>(R.id.tvResult)

val calculator = SuryaSiddhantaCalculator()

btnCalculate.setOnClickListener {
// Get inputs safely, default to current date if empty
val d = etDay.text.toString().toIntOrNull() ?: 1
val m = etMonth.text.toString().toIntOrNull() ?: 1
val y = etYear.text.toString().toIntOrNull() ?: 2026

val res = calculator.calculatePanchang(y, m, d)

val display = """
తేదీ: $d-$m-$y (${res.day})
మాసము: ${res.monthName}
తిథి: ${res.tithi} (${res.tithiTime})
నక్షత్రం: ${res.nakshatra} (${res.nakTime})
వర్జ్యం: ${if (res.varjyam.isEmpty()) "లేదు" else res.varjyam}
""".trimIndent()

tvResult.text = display
}
}
}

// Full Astronomical Logic Class
class SuryaSiddhantaCalculator {

private val months = listOf("చైత్ర", "వైశాఖ మాసము", "జ్యేష్ఠ", "ఆషాఢ మాసము", "శ్రావణ", "భాద్రపద మాసము", "ఆశ్వయుజ", "కార్తీక మాసము", "మార్గశీర్ష్య", "పౌష్య మాసము", "మాఘ", "ఫాల్గుణ మాసము")
private val tNames = listOf("పాఢ్యమి", "విదియ", "తదియ", "చవితి", "పంచమి", "షష్ఠ్ఠి", "సప్తమి", "అష్ఠమి", "నవమి", "దశమి", "ఏకాదశి", "ద్వాదశి", "త్రయోదశి", "చతుర్దశి", "\u25cb పూర్ణిమ", "పాఢ్యమి", "విదియ", "తదియ", "చవితి", "పంచమి", "షష్ఠ్ఠి", "సప్తమి", "అష్ఠమి", "నవమి", "దశమి", "ఏకాదశి", "ద్వాదశి", "త్రయోదశి", "చతుర్దశి", "\u25cf ఆమావాస్య")
private val naks = listOf("అశ్విని", "భరణi", "కృత్తిక", "రోహిణి", "మృగశిర", "ఆర్ద్ర", "పునర్వసు", "పుష్యమి", "ఆశ్లేష", "మఖ", "పుబ్బ", "ఉత్తర", "హస్త", "చిత్త", "స్వాతి", "విశాఖ", "అనూరాధ", "జేష్ఠ్య", "మూల", "పూర్వాషాఢ", "ఉత్తరాషాఢ", "శ్రవణ", "ధనిష్ఠ", "శతభిష", "పూర్వాభాద్ర", "ఉత్తరాభాద్ర", "రేవతి")
private val weekDays = listOf("ఆది", "సోమ", "మంగళ", "బుధ", "గురు", "శుక్ర", "శని")

private val vishFrom = listOf(50.0, 55.0, 21.0, 7.5, 55.0, 21.0, 7.5, 55.0, 32.0, 30.0, 55.0, 21.0, 7.5, 55.0, 21.0, 0.0, 52.0, 14.0, 20.0, 52.0, 20.0, 0.0, 52.0, 20.0, 0.0, 52.0, 30.0)
private val vishTo = listOf(54.0, 60.0, 30.0, 15.0, 60.0, 30.0, 15.0, 60.0, 36.0, 34.0, 60.0, 30.0, 15.0, 60.0, 30.0, 8.0, 60.0, 18.0, 24.0, 60.0, 30.0, 8.0, 60.0, 30.0, 8.0, 60.0, 34.0)

private val EPOCH_DAYS = 10957.5

private fun mod360(n: Double): Double = (n % 360 + 360) % 360

private fun getPositions(ah: Double): PlanetPositions {
val t = ah / 365.25
val ayanamsa = 23.85 + t * 0.013955
val meanLong = mod360(280.466 + 0.98564736 * ah)
val m = mod360(meanLong - 282.94)
val equation = 1.9148 * sin(Math.toRadians(m)) + 0.01997 * sin(Math.toRadians(2 * m))
val sun = mod360(meanLong + equation)
val nirayanaSun = mod360(sun - ayanamsa)
val meanMoon = mod360(218.316 + 13.176396 * ah)
val mMoon = mod360(134.963 + 13.064993 * ah)
val moon = mod360(meanMoon + 6.289 * sin(Math.toRadians(mMoon)))
val nirayanaMoon = mod360(moon - ayanamsa)
return PlanetPositions(nirayanaSun, nirayanaMoon)
}

private fun findAmavasya(ah: Double): Double {
var testAh = ah
repeat(10) {
val p = getPositions(testAh)
val diff = mod360(p.moon - p.sun)
val signedDiff = if (diff > 180) diff - 360 else diff
testAh -= (signedDiff / 12.1907)
}
return testAh
}

fun calculatePanchang(year: Int, month: Int, day: Int, lon: Double = 78.4867): PanchangResult {
val calendar = Calendar.getInstance(TimeZone.getTimeZone("UTC"))
calendar.set(year, month - 1, day, 5, 30, 0)
val ah = (calendar.timeInMillis.toDouble() / 86400000.0) - EPOCH_DAYS

val pos = getPositions(ah)
val timezoneCorr = (lon - 82.5) * 4 / 60

val prevA = findAmavasya(ah - 15)
val nextA = findAmavasya(ah + 15)
val rasiN = (getPositions(nextA).sun / 30).toInt()
val isAdhika = (getPositions(prevA).sun / 30).toInt() == rasiN
val mIdx = if (isAdhika) (rasiN + 1) % 12 else rasiN % 12

val tithiVal = mod360(pos.moon - pos.sun)
val tIdx = (tithiVal / 12).toInt().coerceIn(0, 29)
val nakIdx = (pos.moon / (360.0/27.0)).toInt() % 27

val tEnd = 5.5 + (12 - (tithiVal % 12)) * (24 / 12.19075) + timezoneCorr
val nEnd = 5.5 + ((360.0/27.0) - (pos.moon % (360.0/27.0))) * (24 / 13.176) + timezoneCorr

// Correcting Day of week
val calDay = Calendar.getInstance()
calDay.set(year, month - 1, day)
val dayOfWeek = weekDays[calDay.get(Calendar.DAY_OF_WEEK) - 1]

return PanchangResult(
day = dayOfWeek,
monthName = (if (isAdhika) "అధిక " else "") + months[mIdx],
tithi = tNames[tIdx],
tithiTime = formatTime(tEnd),
nakshatra = naks[nakIdx],
nakTime = formatTime(nEnd),
varjyam = calculateVarjyam(pos.moon, nakIdx)
)
}

private fun calculateVarjyam(moon: Double, nakIdx: Int): String {
val progress = ((moon % (360.0/27.0)) / (360.0/27.0)) * 60.0
return if (vishTo[nakIdx] > progress) {
val s = max(0.0, vishFrom[nakIdx] - progress) * 0.4
val e = (vishTo[nakIdx] - progress) * 0.4
"${formatTime(5.5 + s)} - ${formatTime(5.5 + e)}"
} else ""
}

private fun formatTime(h: Double): String {
val totalMins = (((h + 24) % 24) * 60).toInt()
var hh = (totalMins / 60)
val mm = totalMins % 60
val ap = if (hh >= 12) "రా:" else "ఉ:"
hh = if (hh % 12 == 0) 12 else hh % 12
return "$ap ${hh}:${mm.toString().padStart(2, '0')}"
}

data class PlanetPositions(val sun: Double, val moon: Double)
data class PanchangResult(val day: String, val monthName: String, val tithi: String, val tithiTime: String, val nakshatra: String, val nakTime: String, val varjyam: String)
}