plugins {
id("com.android.application") version "9.1.0" apply false
id("org.jetbrains.kotlin.android") version "2.0.21" apply false
}